from ase import Atoms
print(Atoms())
print(Atoms('H2O'))
#...
