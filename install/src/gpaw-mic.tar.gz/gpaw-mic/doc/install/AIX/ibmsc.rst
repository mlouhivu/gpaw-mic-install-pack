.. _ibmcsc:

============
ibmsc.csc.fi
============

Here you find information about the the system
`<http://www.csc.fi/english/csc/news/customerinfo/IBMSC_phased_out>`_.

Debug like this::

  p690m ~/gpaw/demo> dbx /p/bin/python2.3
  Type 'help' for help.
  reading symbolic information ...warning: no source compiled with -g
  
  (dbx) run
  Python 2.3.4 (#4, May 28 2004, 15:30:35) [C] on aix5
  Type "help", "copyright", "credits" or "license" for more information.
  >>> import grr
