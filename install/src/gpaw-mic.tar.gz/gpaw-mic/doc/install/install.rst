.. _install:

.. toctree::

   installationguide
   platforms_and_architectures
