.. _surveyor:

=====================
surveyor.alcf.anl.gov
=====================

Here you find information about the the system
`<http://www.alcf.anl.gov/support/gettingstarted/index.php>`_.

Please refer to following sections:

.. toctree::
   :maxdepth: 2

   building_with_gcc_on_surveyor
   building_with_xlc_on_surveyor
   using_TAU_on_surveyor

