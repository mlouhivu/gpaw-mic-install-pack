.. _corona:

=============
corona.csc.fi
=============

Here you find information about the the system
`<http://raketti.csc.fi/english/research/Computing_services/computing/servers/corona>`_.

Submit jobs like this::

  qsub -pe cre 8 -cwd -V -S /p/bin/python job.py
