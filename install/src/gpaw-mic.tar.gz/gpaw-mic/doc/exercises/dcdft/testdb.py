import os
os.system('ase-db dcdft.db name=Ca -c +ecut,kpts,width,x,time,iter')
