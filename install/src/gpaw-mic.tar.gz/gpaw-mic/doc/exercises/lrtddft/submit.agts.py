def agts(queue):
    calc1 = queue.add('Na2TDDFT.py',
                      ncpus=2,
                      walltime=60)
    
