.. _lcaotddft:

================================
Time propagation TDDFT with LCAO
================================

This page documents the use of time-propagation TDDFT in :ref:`LCAO
mode <lcao>`.  This page is currently under construction.

Mikael: To build the webpage, install python-sphinx.

Run "sphinx-build . _build" from the gpaw/doc directory to build the
webpage in the directory _build.  Access the webpage in _build/index.html.

The first time you run, building takes a while.
