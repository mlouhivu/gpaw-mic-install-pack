.. _xc:
    
==============
XC Functionals
==============

.. toctree::
   :maxdepth: 2

   functionals
   exx
   rpa
   tpss
   vdw
   vdwcorrection
