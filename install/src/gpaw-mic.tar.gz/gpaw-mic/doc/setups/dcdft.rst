.. _dcdft:

===============
Delta Codes DFT
===============

Codes precision estimated for PBE exchange-correlation functional
on the database of bulk systems from http://molmod.ugent.be/DeltaCodesDFT.

For results see https://cmr.fysik.dtu.dk/.

The scripts used to obtain the results are under :svn:`gpaw/test/big/dcdft/`.
