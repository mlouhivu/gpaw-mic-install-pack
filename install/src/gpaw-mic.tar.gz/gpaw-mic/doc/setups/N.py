# creates: N.LDA
import os
from gpaw.test import gen
gen('N')
os.system('cp N.LDA ../_build')
