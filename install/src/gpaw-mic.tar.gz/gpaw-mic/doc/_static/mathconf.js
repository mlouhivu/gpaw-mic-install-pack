MathJax.Hub.Config({
  TeX: {
    Macros: {
      br: '{\\mathbf r}',
      bk: '{\\mathbf k}',
      bG: '{\\mathbf G}'
    }
  }
});
