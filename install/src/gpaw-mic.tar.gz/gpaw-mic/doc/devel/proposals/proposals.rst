==========================
GPAW enhancement proposals
==========================


.. toctree::
   :maxdepth: 1

   initialization
