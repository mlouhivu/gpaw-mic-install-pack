Non-collinear spin
==================

:Who:
    Kamal, Jens Jørgen

We have a proof-of-concept implementation that works for LDA and LCAO.

To be done:

* Test GGA implementation.
* Compare with other codes.
* Make it work for finite-difference and plane-wave modes.
