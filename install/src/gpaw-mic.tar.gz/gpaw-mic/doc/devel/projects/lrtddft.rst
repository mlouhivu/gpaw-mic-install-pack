Linear response TDDFT (Casida equation)
=======================================

:Who:
    Jussi

Purpose of this branch is to distribute the large Omega matrix
when parallelizing over electron-hole pairs.


