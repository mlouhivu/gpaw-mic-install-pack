Linear response Hubbard +U
===========================================

:Who:
    Keld

To implement the linear response approach to the Hubbard +U method of Cococcioni
and Gironcili [Physical Review B 71, 035105 (2005)] and the following extensions 
by Cococcioni, Kulik, Mazari and co workers. 

The project will evolve in the HubU branch and eventually merge with trunk.
