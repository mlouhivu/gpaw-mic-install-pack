Distributed version control system
==================================

:Who:
    Jens Jørgen

Move the GPAW code from our local centralized version control system (SVN)
to hg_ on bitbucket_ or bazaar_ on launchpad_.

.. _hg: http://mercurial.selenic.com/
.. _bitbucket: https://bitbucket.org/
.. _bazaar: http://bazaar.canonical.com/en/
.. _launchpad: https://launchpad.net/
