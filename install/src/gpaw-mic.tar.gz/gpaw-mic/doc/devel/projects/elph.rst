Electron-phonon interaction
===========================

:Who:
    Kristen Kaasbjerg

A supercell method for calculating the electron-phonon interaction in bulk
crystals, molecules, nanoscale contacts etc has been implemented (available from
gpaw/elph/electronphonon.py).
