Ehrenfest dynamics
==================

:Who:
    Ari, Christian

The implementation of Ehrenfest dynamics works and is now available in
the development version of GPAW. The TODO list includes documentation,
example scripts (high priority) and structural improvements in the
code towards something reminiscent of the MD module in ASE. The latter
requires a significant amount of work, and hence small improvements
such as better automated output (.traj files, for example) will be
done first.
