Orbital-density dependent functionals and self-interaction correction
=====================================================================

:Who:
    Peter
