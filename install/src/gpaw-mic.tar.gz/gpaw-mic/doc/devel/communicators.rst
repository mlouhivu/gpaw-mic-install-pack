.. _communicators:

MPI communicators
=================

.. autoclass:: gpaw.mpi._Communicator
   :members:
   :show-inheritance:

